import React from 'react';
import { X, MapPin, Phone, Instagram, Clock, ExternalLink, MessageCircle, Navigation, Utensils, Star, Quote, ThumbsUp, MessageSquare } from 'lucide-react';
import { Language, translations } from '../../lib/translations';

interface RestaurantLocationModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const RestaurantLocationModal: React.FC<RestaurantLocationModalProps> = ({
  isOpen,
  onClose,
  lang
}) => {
  const t = translations[lang];
  if (!isOpen) return null;

  const googleMapsUrl = 'https://share.google/uBXjzlgV6n3vL9ha3';
  const instagramUrl = 'https://instagram.com/prime_cafe_bulvar';
  const whatsappUrl = `https://wa.me/${t.whatsappContact.replace(/\D/g, '')}`;
  const phoneUrl = `tel:${t.phoneContact.replace(/\s/g, '')}`;

  const customerReviews = [
    {
      id: 1,
      author: 'Alisher K.',
      role: 'Google Local Guide • 142 reviews',
      rating: 5,
      date: '2 days ago',
      text: 'Best restaurant experience in Samarkand! The steaks were exceptionally cooked, the QR table ordering was seamless, and the staff was extremely warm.',
      verified: true
    },
    {
      id: 2,
      author: 'Elena Rostova',
      role: 'Verified Google Visitor',
      rating: 5,
      date: '1 week ago',
      text: 'Wonderful atmosphere, delicious pilaf and fresh craft tea. Fast service and super clean table arrangement. Highly recommended!',
      verified: true
    },
    {
      id: 3,
      author: 'Sardor Temirov',
      role: 'Local Guide',
      rating: 5,
      date: '2 weeks ago',
      text: 'Super clean, hospitable staff, and instant table delivery. The online digital menu makes ordering effortless!',
      verified: true
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-zinc-900/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white border border-zinc-200 text-zinc-900 rounded-3xl max-w-lg w-full shadow-2xl overflow-hidden relative p-5 sm:p-6 space-y-4 max-h-[90vh] overflow-y-auto custom-scrollbar">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-zinc-100 pb-3.5 sticky top-0 bg-white z-10">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-orange-500 text-white flex items-center justify-center font-bold shadow-md shadow-orange-500/20 shrink-0">
              <Utensils className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-zinc-900 uppercase tracking-tight">{t.appTitle}</h2>
              <p className="text-xs text-orange-600 font-bold flex items-center space-x-1">
                <MapPin className="w-3.5 h-3.5 shrink-0" />
                <span>Samarkand, Uzbekistan</span>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-zinc-400 hover:text-zinc-800 bg-zinc-100 rounded-full transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Location Banner Image */}
        <div className="relative h-40 rounded-2xl overflow-hidden border border-zinc-200 group bg-zinc-900 shrink-0">
          <img
            src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=80"
            alt="Prime Restaurant Samarkand"
            className="w-full h-full object-cover opacity-85 group-hover:scale-105 transition-transform duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-zinc-900/90 via-zinc-900/30 to-transparent flex flex-col justify-end p-4 text-white">
            <span className="bg-orange-500 text-white font-black text-[10px] px-2 py-0.5 rounded-md uppercase tracking-wider w-fit mb-1">
              📍 Prime Restaurant
            </span>
            <h3 className="font-extrabold text-base leading-snug">Samarkand Branch</h3>
            <p className="text-xs text-zinc-300 font-medium">Samarkand, Uzbekistan</p>
          </div>
        </div>

        {/* Contact & Social Quick Actions Bento Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          
          {/* Phone Call */}
          <a
            href={phoneUrl}
            className="bg-zinc-50 hover:bg-orange-50/80 border border-zinc-200 hover:border-orange-200 rounded-2xl p-3 flex items-center space-x-3 transition-all group"
          >
            <div className="p-2 bg-orange-500 text-white rounded-xl shadow-xs shrink-0 group-hover:scale-110 transition-transform">
              <Phone className="w-4 h-4" />
            </div>
            <div className="overflow-hidden">
              <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">Phone Line</span>
              <span className="text-xs font-black text-zinc-900 block truncate">{t.phoneContact}</span>
            </div>
          </a>

          {/* WhatsApp Direct Chat */}
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-zinc-50 hover:bg-emerald-50/80 border border-zinc-200 hover:border-emerald-200 rounded-2xl p-3 flex items-center space-x-3 transition-all group"
          >
            <div className="p-2 bg-emerald-500 text-white rounded-xl shadow-xs shrink-0 group-hover:scale-110 transition-transform">
              <MessageCircle className="w-4 h-4" />
            </div>
            <div className="overflow-hidden">
              <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">WhatsApp Chat</span>
              <span className="text-xs font-black text-zinc-900 block truncate">{t.whatsappContact}</span>
            </div>
          </a>

          {/* Instagram Handle */}
          <a
            href={instagramUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-zinc-50 hover:bg-pink-50/80 border border-zinc-200 hover:border-pink-200 rounded-2xl p-3 flex items-center space-x-3 transition-all group"
          >
            <div className="p-2 bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 text-white rounded-xl shadow-xs shrink-0 group-hover:scale-110 transition-transform">
              <Instagram className="w-4 h-4" />
            </div>
            <div className="overflow-hidden">
              <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">Instagram</span>
              <span className="text-xs font-black text-zinc-900 block truncate">@prime_cafe_bulvar</span>
            </div>
          </a>

          {/* Working Hours */}
          <div className="bg-zinc-50 border border-zinc-200 rounded-2xl p-3 flex items-center space-x-3">
            <div className="p-2 bg-zinc-800 text-amber-400 rounded-xl shrink-0">
              <Clock className="w-4 h-4" />
            </div>
            <div className="overflow-hidden">
              <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">Working Hours</span>
              <span className="text-xs font-black text-zinc-900 block truncate">09:00 - 23:00 Daily</span>
            </div>
          </div>

        </div>

        {/* Google Maps External Directions Button */}
        <a
          href={googleMapsUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="w-full bg-orange-500 hover:bg-orange-600 text-white font-extrabold py-3 rounded-2xl text-xs shadow-md shadow-orange-500/20 transition-all flex items-center justify-center space-x-2"
        >
          <Navigation className="w-4 h-4" />
          <span>Open Directions on Google Maps</span>
          <ExternalLink className="w-3.5 h-3.5 opacity-80" />
        </a>

        {/* Google Maps Customer Reviews & Feedback Section */}
        <div className="bg-zinc-50 border border-zinc-200/90 rounded-2xl p-4 space-y-3 mt-2">
          
          {/* Header & Rating summary */}
          <div className="flex items-center justify-between border-b border-zinc-200/80 pb-3">
            <div>
              <div className="flex items-center space-x-1.5">
                <span className="text-amber-500 font-black text-lg">4.9</span>
                <div className="flex items-center text-amber-400">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                  ))}
                </div>
              </div>
              <p className="text-[11px] text-zinc-500 font-bold mt-0.5">
                Based on <span className="text-zinc-900 font-black">280+ Google Maps Reviews</span>
              </p>
            </div>

            <a
              href={googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-white hover:bg-zinc-100 border border-zinc-200 text-zinc-800 font-black text-[11px] px-3 py-1.5 rounded-xl transition-all shadow-2xs flex items-center space-x-1"
            >
              <span>Write Review</span>
              <ExternalLink className="w-3 h-3 text-zinc-400" />
            </a>
          </div>

          {/* Customer Review Quotes */}
          <div className="space-y-2.5">
            <p className="text-[10px] font-black uppercase tracking-wider text-zinc-400 flex items-center space-x-1">
              <MessageSquare className="w-3 h-3 text-orange-500" />
              <span>Recent Customer Feedback</span>
            </p>

            {customerReviews.map(review => (
              <div key={review.id} className="bg-white border border-zinc-200/80 rounded-xl p-3 space-y-1.5 shadow-2xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="w-6 h-6 rounded-full bg-orange-100 text-orange-700 font-extrabold text-[10px] flex items-center justify-center">
                      {review.author[0]}
                    </div>
                    <div>
                      <span className="text-xs font-black text-zinc-900 block leading-tight">{review.author}</span>
                      <span className="text-[9px] text-zinc-400 font-medium block">{review.role}</span>
                    </div>
                  </div>
                  <div className="flex items-center text-amber-400 space-x-0.5">
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} className="w-3 h-3 fill-amber-400 text-amber-400" />
                    ))}
                  </div>
                </div>

                <p className="text-xs text-zinc-700 italic font-medium leading-relaxed">
                  "{review.text}"
                </p>
              </div>
            ))}
          </div>

          {/* Bottom Link to Google Maps */}
          <div className="pt-1 text-center">
            <a
              href={googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-orange-600 hover:text-orange-700 text-xs font-extrabold inline-flex items-center space-x-1 transition-colors"
            >
              <ThumbsUp className="w-3.5 h-3.5" />
              <span>See all customer photos & reviews on Google Maps →</span>
            </a>
          </div>

        </div>

      </div>
    </div>
  );
};

