import { formatSom } from '../../utils/currency';
import React, { useState, useEffect, useRef } from 'react';
import { CartItem, LoyaltyMember, GoogleUser } from '../../types';
import { X, Trash2, Plus, Minus, Sparkles, CreditCard, Wallet, ShieldCheck, CheckCircle2, Phone, Mail, Send, KeyRound, AlertCircle, LogIn } from 'lucide-react';
import { Language, translations } from '../../lib/translations';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (cartItemId: string, newQty: number) => void;
  onRemoveItem: (cartItemId: string) => void;
  tableNumber: number;
  customerName: string;
  setCustomerName: (name: string) => void;
  customerPhoneOrEmail: string;
  setCustomerPhoneOrEmail: (val: string) => void;
  confirmationCode: string;
  setConfirmationCode: (code: string) => void;
  loyaltyMember: LoyaltyMember | null;
  onVerifyLoyalty: (phoneOrEmail: string, code: string) => void;
  googleUser?: GoogleUser | null;
  onOpenGoogleAuth?: () => void;
  onSubmitOrder: (orderData: {
    paymentMethod: 'pay_at_counter' | 'card' | 'cash';
    loyaltyPointsRedeemed: number;
    orderNote: string;
  }) => void;
  lang: Language;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  tableNumber,
  customerName,
  setCustomerName,
  customerPhoneOrEmail,
  setCustomerPhoneOrEmail,
  confirmationCode,
  setConfirmationCode,
  loyaltyMember,
  onVerifyLoyalty,
  googleUser,
  onOpenGoogleAuth,
  onSubmitOrder,
  lang
}) => {
  const t = translations[lang];
  const [redeemPoints, setRedeemPoints] = useState<boolean>(false);
  const [paymentMethod, setPaymentMethod] = useState<'pay_at_counter' | 'card' | 'cash'>('pay_at_counter');
  const [orderNote, setOrderNote] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Verification State
  const [contactType, setContactType] = useState<'telegram' | 'gmail' | 'phone'>('gmail');
  const [generatedOtp, setGeneratedOtp] = useState<string | null>(null);
  const [userOtpInput, setUserOtpInput] = useState<string>('');
  const [isContactVerified, setIsContactVerified] = useState<boolean>(!!googleUser);
  const [showOtpModal, setShowOtpModal] = useState<boolean>(false);
  const [otpError, setOtpError] = useState<string | null>(null);

  useEffect(() => {
    if (googleUser) {
      if (!customerName) setCustomerName(googleUser.name);
      if (!customerPhoneOrEmail) setCustomerPhoneOrEmail(googleUser.email);
      setIsContactVerified(true);
    }
  }, [googleUser]);

  const [telegramConfigured, setTelegramConfigured] = useState<boolean | null>(null);
  const [telegramStatus, setTelegramStatus] = useState<'idle' | 'waiting' | 'expired'>('idle');
  const telegramPollRef = useRef<number | null>(null);

  useEffect(() => {
    fetch('/api/auth/telegram/config')
      .then(r => r.json())
      .then(d => setTelegramConfigured(!!d.configured))
      .catch(() => setTelegramConfigured(false));
    return () => {
      if (telegramPollRef.current) window.clearInterval(telegramPollRef.current);
    };
  }, []);

  if (!isOpen) return null;

  // Bill Calculations
  const subtotal = cartItems.reduce((acc, item) => acc + item.itemTotal, 0);
  const tax = subtotal * 0.08; // 8% Tax
  const serviceCharge = subtotal * 0.05; // 5% Service Charge

  // Loyalty Discount Calculation — 1 point is worth 100 so'm when redeemed.
  let pointsToRedeem = 0;
  let loyaltyDiscount = 0;
  if (redeemPoints && loyaltyMember && loyaltyMember.pointsBalance >= 100) {
    const maxDiscountAllowed = subtotal * 0.5;
    const availableDiscountSom = loyaltyMember.pointsBalance * 100;
    loyaltyDiscount = Math.min(maxDiscountAllowed, availableDiscountSom);
    pointsToRedeem = Math.floor(loyaltyDiscount / 100);
    loyaltyDiscount = pointsToRedeem * 100; // re-derive so it's an exact multiple of 100 so'm
  }

  const finalTotal = Math.max(0, subtotal + tax + serviceCharge - loyaltyDiscount);
  const pointsToEarn = Math.round(finalTotal / 1000);

  // Send Verification Code Action
  const handleSendVerificationCode = () => {
    if (!customerPhoneOrEmail.trim()) {
      const channelLabel = contactType === 'telegram' ? 'Telegram handle or phone' : contactType === 'gmail' ? 'Gmail address' : 'Phone number';
      alert(`Please enter your ${channelLabel} first.`);
      return;
    }
    const code = Math.floor(1000 + Math.random() * 9000).toString();
    setGeneratedOtp(code);
    setUserOtpInput('');
    setOtpError(null);
    setShowOtpModal(true);
  };

  // Real Telegram verification: opens the restaurant's bot with a one-time
  // token, then polls until the customer has pressed Start in Telegram
  // (which proves they control that account) — nothing is faked here.
  const handleTelegramVerify = async () => {
    if (!telegramConfigured) {
      alert('Telegram verification is not set up yet for this restaurant.');
      return;
    }
    try {
      const res = await fetch('/api/auth/telegram/start', { method: 'POST' });
      if (!res.ok) {
        alert('Could not start Telegram verification. Please try again.');
        return;
      }
      const { token, deepLink } = await res.json();
      window.open(deepLink, '_blank');
      setTelegramStatus('waiting');

      const startedAt = Date.now();
      telegramPollRef.current = window.setInterval(async () => {
        if (Date.now() - startedAt > 5.5 * 60_000) {
          window.clearInterval(telegramPollRef.current!);
          setTelegramStatus('expired');
          return;
        }
        try {
          const statusRes = await fetch(`/api/auth/telegram/status/${token}`);
          const status = await statusRes.json();
          if (status.status === 'verified') {
            window.clearInterval(telegramPollRef.current!);
            const identifier = status.telegramUsername ? `@${status.telegramUsername}` : `telegram-${status.telegramUserId}`;
            setCustomerPhoneOrEmail(identifier);
            if (!customerName && status.telegramFirstName) setCustomerName(status.telegramFirstName);
            setIsContactVerified(true);
            setTelegramStatus('idle');
            onVerifyLoyalty(identifier, '');
          } else if (status.status === 'expired' || status.status === 'not_found') {
            window.clearInterval(telegramPollRef.current!);
            setTelegramStatus('expired');
          }
        } catch {
          // transient network hiccup — keep polling, don't give up on one failure
        }
      }, 2500);
    } catch {
      alert('Could not reach the server to start Telegram verification.');
    }
  };

  // Instant 1-Click Verification for Gmail only (Telegram uses the real
  // bot-based flow above now — see handleTelegramVerify)
  const handleInstantQuickVerify = (method: 'telegram' | 'gmail') => {
    const value = customerPhoneOrEmail.trim();
    if (!value) {
      const channelLabel = method === 'telegram' ? 'Telegram handle or phone' : 'Gmail address';
      alert(`Please enter your ${channelLabel} first.`);
      return;
    }
    const code = Math.floor(1000 + Math.random() * 9000).toString();
    setGeneratedOtp(code);
    setIsContactVerified(true);
    setConfirmationCode(code);
    onVerifyLoyalty(value, code);
  };

  // Confirm Verification Code
  const handleConfirmOtp = () => {
    if (userOtpInput.trim() === generatedOtp) {
      setIsContactVerified(true);
      setShowOtpModal(false);
      setOtpError(null);
      // Auto-populate loyalty code if empty
      if (!confirmationCode) {
        setConfirmationCode(generatedOtp);
        onVerifyLoyalty(customerPhoneOrEmail, generatedOtp);
      }
    } else {
      setOtpError(t.incorrectCode);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (cartItems.length === 0 || isSubmitting) return;

    setIsSubmitting(true);
    onSubmitOrder({
      paymentMethod,
      loyaltyPointsRedeemed: isContactVerified ? pointsToRedeem : 0,
      orderNote
    });
    setIsSubmitting(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-zinc-900/70 backdrop-blur-sm animate-fadeIn">
      <div className="absolute inset-y-0 right-0 max-w-full flex w-full sm:w-auto">
        <div className="w-full sm:w-screen sm:max-w-md bg-zinc-900 text-white flex flex-col shadow-2xl h-full">
          
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-zinc-800 flex items-center justify-between bg-zinc-900 shrink-0">
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-sm font-black tracking-wider uppercase text-white">{t.yourCart}</h2>
                <span className="bg-orange-500 text-[10px] text-white px-2 py-0.5 rounded-full font-extrabold">
                  {t.table} #{tableNumber}
                </span>
              </div>
              <p className="text-zinc-400 text-xs mt-0.5">{t.itemsCount.replace('{count}', String(cartItems.length))}</p>
            </div>

            <button
              onClick={onClose}
              className="p-2 text-zinc-400 hover:text-white bg-zinc-800 rounded-full transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cart Content */}
          <div className="p-4 sm:p-5 overflow-y-auto flex-1 space-y-6 custom-scrollbar">
            
            {/* Cart Items List */}
            {cartItems.length === 0 ? (
              <div className="text-center py-12 text-zinc-500 space-y-3">
                <p className="font-bold text-zinc-400">{t.noDishesFound}</p>
              </div>
            ) : (
              <div className="space-y-3">
                {cartItems.map((item) => (
                  <div key={item.cartItemId} className="bg-zinc-800/80 border border-zinc-700/60 rounded-xl p-3 flex justify-between space-x-3">
                    <img src={item.menuItem.image} alt={item.menuItem.name} className="w-14 h-14 rounded-lg object-cover shrink-0" referrerPolicy="no-referrer" />
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-start">
                        <h4 className="font-bold text-xs text-white truncate">{item.menuItem.name}</h4>
                        <button onClick={() => onRemoveItem(item.cartItemId)} className="text-zinc-500 hover:text-rose-400 p-0.5">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      {item.selectedCustomizations.length > 0 && (
                        <p className="text-[10px] text-zinc-400 truncate mt-0.5">
                          {item.selectedCustomizations.map(c => c.optionName).join(', ')}
                        </p>
                      )}
                      <div className="flex justify-between items-center mt-2">
                        <span className="text-xs font-black text-orange-400">{formatSom(item.itemTotal)}</span>
                        <div className="flex items-center bg-zinc-900 rounded-lg border border-zinc-700 p-0.5">
                          <button onClick={() => onUpdateQuantity(item.cartItemId, item.quantity - 1)} className="p-1 text-zinc-400 hover:text-white">
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="w-5 text-center text-xs font-bold text-white">{item.quantity}</span>
                          <button onClick={() => onUpdateQuantity(item.cartItemId, item.quantity + 1)} className="p-1 text-zinc-400 hover:text-white">
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Verification Section */}
            {cartItems.length > 0 && (
              <div className="bg-zinc-800/90 border border-zinc-700/80 rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <ShieldCheck className="w-4 h-4 text-green-400" />
                    <span className="text-xs font-bold uppercase tracking-wider text-white">
                      {t.verifyMethod}
                    </span>
                  </div>
                  {isContactVerified && (
                    <span className="bg-green-500/20 text-green-400 text-[10px] font-bold px-2 py-0.5 rounded-md border border-green-500/30 flex items-center space-x-1">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>{t.scanVerified}</span>
                    </span>
                  )}
                </div>

                {/* Google OAuth Quick Sign In Card in Cart Drawer */}
                {!googleUser && onOpenGoogleAuth && (
                  <div className="bg-gradient-to-r from-zinc-800 to-zinc-900 border border-zinc-700/80 rounded-2xl p-3.5 flex items-center justify-between">
                    <div className="flex items-center space-x-2.5">
                      <div className="w-8 h-8 rounded-xl bg-white flex items-center justify-center shrink-0 shadow-xs">
                        <svg className="w-4 h-4" viewBox="0 0 24 24">
                          <path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z" />
                          <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.24v3.15C3.26 21.36 7.37 24 12 24z" />
                          <path fill="#FBBC05" d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.24C.45 8.15 0 9.99 0 12s.45 3.85 1.24 5.42l4.04-3.15z" />
                          <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.37 0 3.26 2.64 1.24 6.58l4.04 3.15c.95-2.83 3.6-4.98 6.72-4.98z" />
                        </svg>
                      </div>
                      <div>
                        <span className="text-xs font-bold text-white block">Fast Checkout with Gmail</span>
                        <span className="text-[10px] text-zinc-400 block">Auto-fill & earn loyalty points</span>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={onOpenGoogleAuth}
                      className="bg-white hover:bg-zinc-100 text-zinc-900 font-extrabold px-3 py-1.5 rounded-xl text-xs shrink-0 transition-colors"
                    >
                      Sign In
                    </button>
                  </div>
                )}

                {/* Customer Details Inputs */}
                <div className="space-y-2">
                  <div>
                    <label className="text-[10px] font-bold text-zinc-400 uppercase">{t.customerName}</label>
                    <input
                      type="text"
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder={t.customerNamePlaceholder}
                      className="w-full bg-zinc-900 border border-zinc-700 rounded-xl px-3 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:ring-1 focus:ring-orange-500"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-zinc-400 uppercase">{t.contactInfo}</label>
                    <div className="flex space-x-2 mt-1">
                      <input
                        type="text"
                        value={customerPhoneOrEmail}
                        onChange={(e) => {
                          setCustomerPhoneOrEmail(e.target.value);
                          setIsContactVerified(false);
                        }}
                        placeholder="@telegram_id or email / phone"
                        className="flex-1 bg-zinc-900 border border-zinc-700 rounded-xl px-3 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:ring-1 focus:ring-orange-500"
                      />
                      <button
                        type="button"
                        onClick={handleSendVerificationCode}
                        className="bg-orange-500 hover:bg-orange-600 text-white font-bold px-3 py-2 rounded-xl text-xs whitespace-nowrap transition-colors"
                      >
                        {t.sendCode}
                      </button>
                    </div>
                  </div>

                  {/* 1-Click Instant Quick Verify Option */}
                  {!isContactVerified && (
                    <div className="pt-2 border-t border-zinc-700/60 flex items-center justify-between text-[10px]">
                      <span className="text-zinc-400">{t.quickVerify}:</span>
                      <div className="flex space-x-1.5">
                        <button
                          type="button"
                          onClick={handleTelegramVerify}
                          disabled={telegramStatus === 'waiting'}
                          className="bg-sky-500/20 text-sky-300 hover:bg-sky-500/30 border border-sky-500/30 px-2 py-1 rounded-lg font-bold flex items-center space-x-1 disabled:opacity-60"
                        >
                          <Send className="w-2.5 h-2.5" />
                          <span>
                            {telegramStatus === 'waiting'
                              ? 'Waiting for Telegram…'
                              : telegramStatus === 'expired'
                              ? 'Expired — tap to retry'
                              : 'Telegram'}
                          </span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleInstantQuickVerify('gmail')}
                          className="bg-rose-500/20 text-rose-300 hover:bg-rose-500/30 border border-rose-500/30 px-2 py-1 rounded-lg font-bold flex items-center space-x-1"
                        >
                          <Mail className="w-2.5 h-2.5" />
                          <span>Gmail</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Payment Method Selector */}
            {cartItems.length > 0 && (
              <div className="bg-zinc-800/90 border border-zinc-700/80 rounded-2xl p-4 space-y-3">
                <span className="text-xs font-bold uppercase tracking-wider text-white block">{t.paymentMethod}</span>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('pay_at_counter')}
                    className={`p-2.5 rounded-xl border text-center transition-all ${
                      paymentMethod === 'pay_at_counter'
                        ? 'bg-orange-500/20 border-orange-500 text-orange-400 font-bold'
                        : 'bg-zinc-900 border-zinc-700 text-zinc-400 hover:text-white'
                    }`}
                  >
                    <Wallet className="w-4 h-4 mx-auto mb-1" />
                    <span className="text-[10px] block font-bold">{t.payCounter}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('cash')}
                    className={`p-2.5 rounded-xl border text-center transition-all ${
                      paymentMethod === 'cash'
                        ? 'bg-orange-500/20 border-orange-500 text-orange-400 font-bold'
                        : 'bg-zinc-900 border-zinc-700 text-zinc-400 hover:text-white'
                    }`}
                  >
                    <Wallet className="w-4 h-4 mx-auto mb-1" />
                    <span className="text-[10px] block font-bold">{t.cash}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('card')}
                    className={`p-2.5 rounded-xl border text-center transition-all ${
                      paymentMethod === 'card'
                        ? 'bg-orange-500/20 border-orange-500 text-orange-400 font-bold'
                        : 'bg-zinc-900 border-zinc-700 text-zinc-400 hover:text-white'
                    }`}
                  >
                    <CreditCard className="w-4 h-4 mx-auto mb-1" />
                    <span className="text-[10px] block font-bold">{t.card}</span>
                  </button>
                </div>
              </div>
            )}

            {/* Bill Summary */}
            {cartItems.length > 0 && (
              <div className="bg-zinc-800/90 border border-zinc-700/80 rounded-2xl p-4 space-y-2 text-xs">
                <div className="flex justify-between text-zinc-400">
                  <span>{t.subtotal}</span>
                  <span>{formatSom(subtotal)}</span>
                </div>
                <div className="flex justify-between text-zinc-400">
                  <span>{t.tax}</span>
                  <span>{formatSom((tax + serviceCharge))}</span>
                </div>
                {loyaltyDiscount > 0 && (
                  <div className="flex justify-between text-green-400 font-bold">
                    <span>{t.payWithPoints}</span>
                    <span>{formatSom(-(loyaltyDiscount))}</span>
                  </div>
                )}
                <div className="border-t border-zinc-700 pt-2 flex justify-between text-sm font-black text-white">
                  <span>{t.total}</span>
                  <span className="text-orange-400">{formatSom(finalTotal)}</span>
                </div>
              </div>
            )}

          </div>

          {/* Submit Action Footer */}
          {cartItems.length > 0 && (
            <div className="p-4 border-t border-zinc-800 bg-zinc-900 shrink-0">
              <button
                onClick={handleSubmit}
                disabled={isSubmitting}
                className="w-full bg-orange-500 hover:bg-orange-600 text-white font-black py-3.5 rounded-xl shadow-lg shadow-orange-500/20 flex items-center justify-between px-4 transition-all active:scale-98"
              >
                <span>{t.submitOrderKitchen}</span>
                <span className="text-sm font-extrabold">{formatSom(finalTotal)}</span>
              </button>
            </div>
          )}

        </div>
      </div>

      {/* Verification Code OTP Dialog */}
      {showOtpModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="bg-zinc-900 border border-zinc-800 text-white rounded-2xl max-w-xs w-full p-5 shadow-2xl relative">
            <button
              onClick={() => setShowOtpModal(false)}
              className="absolute top-3 right-3 text-zinc-400 hover:text-white p-1"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="text-center mb-4">
              <KeyRound className="w-8 h-8 text-orange-500 mx-auto mb-2" />
              <h3 className="text-sm font-bold text-white">{t.verificationCode}</h3>
              <p className="text-xs text-zinc-400 mt-1">
                A verification code was generated for <strong>{customerPhoneOrEmail}</strong>
              </p>
              <div className="bg-orange-500/20 border border-orange-500/40 text-orange-300 font-mono text-lg font-black py-1.5 px-3 rounded-xl mt-2 inline-block">
                {generatedOtp}
              </div>
            </div>

            <div className="space-y-3">
              <input
                type="text"
                maxLength={4}
                value={userOtpInput}
                onChange={(e) => setUserOtpInput(e.target.value)}
                placeholder={t.enter4DigitCode}
                className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-3 py-2.5 text-center text-lg tracking-widest font-mono text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
              />

              {otpError && (
                <p className="text-[11px] text-rose-400 text-center font-medium">{otpError}</p>
              )}

              <button
                onClick={handleConfirmOtp}
                className="w-full bg-orange-500 hover:bg-orange-600 text-white font-bold py-2.5 rounded-xl text-xs transition-colors"
              >
                {t.confirmCode}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

