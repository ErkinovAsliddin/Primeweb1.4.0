export type Category = 'appetizers' | 'mains' | 'drinks' | 'desserts' | 'specials';

export type DietaryTag = 'vegetarian' | 'vegan' | 'gluten-free' | 'halal' | 'spicy' | 'chef-recommendation';

export interface CustomizationOption {
  id: string;
  name: string;
  price: number;
}

export interface CustomizationGroup {
  id: string;
  title: string;
  required: boolean;
  maxSelect?: number;
  options: CustomizationOption[];
}

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: Category;
  image: string;
  stock: number;
  isAvailable: boolean;
  dietary: DietaryTag[];
  prepTimeMinutes: number;
  calories?: number;
  customizations?: CustomizationGroup[];
}

export interface SelectedCustomization {
  groupTitle: string;
  optionName: string;
  price: number;
}

export interface CartItem {
  cartItemId: string;
  menuItem: MenuItem;
  quantity: number;
  selectedCustomizations: SelectedCustomization[];
  specialInstructions?: string;
  itemTotal: number;
}

export type OrderStatus = 'pending' | 'preparing' | 'ready' | 'served' | 'paid' | 'cancelled';
export type PaymentStatus = 'unpaid' | 'paid';

export interface Order {
  id: string;
  tableNumber: number;
  customerName: string;
  customerPhoneOrEmail: string;
  items: CartItem[];
  subtotal: number;
  tax: number;
  serviceCharge: number;
  discount: number;
  totalAmount: number;
  status: OrderStatus;
  paymentStatus: PaymentStatus;
  paymentMethod?: 'cash' | 'card' | 'loyalty_points' | 'pay_at_counter';
  createdAt: string;
  updatedAt: string;
  estimatedMinutes: number;
  loyaltyPointsEarned: number;
  loyaltyPointsRedeemed: number;
  orderNote?: string;
}

export interface LoyaltyMember {
  id: string;
  name: string;
  phoneOrEmail: string;
  confirmationCode: string;
  pointsBalance: number;
  tier: 'Silver' | 'Gold' | 'Platinum';
  totalSpent: number;
  ordersCount: number;
  joinedDate: string;
}

export interface Table {
  tableNumber: number;
  capacity: number;
  status: 'available' | 'seated' | 'ordering' | 'eating' | 'bill_requested';
  currentOrderId?: string;
  activeItemsCount?: number;
}

export interface InventoryLog {
  id: string;
  menuItemId: string;
  menuItemName: string;
  changeAmount: number;
  newStock: number;
  reason: 'customer_order' | 'restock' | 'manual_adjustment' | 'spoilage';
  timestamp: string;
}

export type AppViewMode = 'customer' | 'kitchen' | 'admin';

export interface GoogleUser {
  id: string;
  email: string;
  name: string;
  picture?: string;
  givenName?: string;
  phone?: string;
}
