import React, { useState, useEffect } from 'react';
import {
  AppViewMode,
  MenuItem,
  Order,
  Table,
  LoyaltyMember,
  CartItem,
  OrderStatus,
  GoogleUser
} from './types';
import { INITIAL_MENU_ITEMS, INITIAL_ORDERS, INITIAL_TABLES, INITIAL_LOYALTY_MEMBERS } from './data/mockData';
import { Language } from './lib/translations';
import { HeaderNav } from './components/HeaderNav';
import { TableConfirmModal } from './components/customer/TableConfirmModal';
import { CustomerView } from './components/customer/CustomerView';
import { ItemCustomizerModal } from './components/customer/ItemCustomizerModal';
import { CartDrawer } from './components/customer/CartDrawer';
import { OrderStatusTracker } from './components/customer/OrderStatusTracker';
import { OrderHistoryModal } from './components/customer/OrderHistoryModal';
import { QRScannerModal } from './components/customer/QRScannerModal';
import { GoogleAuthModal } from './components/customer/GoogleAuthModal';
import { RestaurantLocationModal } from './components/customer/RestaurantLocationModal';
import { WelcomeSplash } from './components/customer/WelcomeSplash';
import { KitchenDisplay } from './components/kitchen/KitchenDisplay';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { AdminAuthModal } from './components/admin/AdminAuthModal';

export default function App() {
  // Multilingual State
  const [lang, setLang] = useState<Language>('uz'); // Default to Uzbek as requested

  // App View State
  const [currentView, setCurrentView] = useState<AppViewMode>('customer');
  const [isRealtimeConnected, setIsRealtimeConnected] = useState<boolean>(true);

  // Admin & Kitchen Security Authentication State.
  // The actual credential check happens server-side (hashed password, real
  // session cookie) — these booleans just mirror what the server told us via
  // /api/auth/me so the UI can show/hide the right screens.
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(false);
  const [isKitchenAuthenticated, setIsKitchenAuthenticated] = useState<boolean>(false);
  const [isAdminAuthModalOpen, setIsAdminAuthModalOpen] = useState<boolean>(false);
  const [authModalTarget, setAuthModalTarget] = useState<'kitchen' | 'admin'>('admin');

  // Simple visible error queue so failed actions are never silently
  // swallowed or faked as successes.
  const [errorToast, setErrorToast] = useState<string | null>(null);
  const showError = (message: string) => {
    setErrorToast(message);
    window.setTimeout(() => setErrorToast(null), 5000);
  };

  // Turns the server's zod validation error shape into a readable message,
  // e.g. "price: Number must be greater than 0" instead of a generic
  // "invalid request" that gives no clue what to fix.
  const describeApiError = (body: any): string | null => {
    if (!body) return null;
    if (body.details?.fieldErrors) {
      const fields = Object.entries(body.details.fieldErrors)
        .filter(([, msgs]) => Array.isArray(msgs) && (msgs as string[]).length > 0)
        .map(([field, msgs]) => `${field}: ${(msgs as string[])[0]}`);
      if (fields.length > 0) return `Invalid: ${fields.join('; ')}`;
    }
    return body.error || null;
  };

  const handleUpdateAdminPassword = async (newPass: string) => {
    try {
      const res = await fetch('/api/auth/admin/change-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ newPassword: newPass })
      });
      if (!res.ok) throw new Error('Failed to update password');
    } catch {
      showError('Could not update admin password. Please try again.');
    }
  };

  const handleUpdateKitchenPin = async (newPin: string) => {
    try {
      const res = await fetch('/api/auth/kitchen/change-pin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ newPassword: newPin })
      });
      if (!res.ok) throw new Error('Failed to update PIN');
    } catch {
      showError('Could not update kitchen PIN. Please try again.');
    }
  };

  // Restore session state on load/refresh (server is the source of truth).
  useEffect(() => {
    fetch('/api/auth/me')
      .then(r => (r.ok ? r.json() : { role: null }))
      .then(({ role }) => {
        setIsAdminAuthenticated(role === 'admin');
        setIsKitchenAuthenticated(role === 'admin' || role === 'kitchen');
      })
      .catch(() => {});
  }, []);

  // QR Camera Scanner State
  const [isQRScannerModalOpen, setIsQRScannerModalOpen] = useState<boolean>(false);

  // Data Stores
  const [menuItems, setMenuItems] = useState<MenuItem[]>(INITIAL_MENU_ITEMS);
  const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS);
  const [tables, setTables] = useState<Table[]>(INITIAL_TABLES);
  const [loyaltyMembers, setLoyaltyMembers] = useState<LoyaltyMember[]>(INITIAL_LOYALTY_MEMBERS);

  // Table State
  const [tableNumber, setTableNumber] = useState<number | null>(null);
  const [isTableModalOpen, setIsTableModalOpen] = useState<boolean>(false);

  // Cart & Customizer State
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [selectedDishForCustomization, setSelectedDishForCustomization] = useState<MenuItem | null>(null);

  // Loyalty & Customer Identification State
  const [googleUser, setGoogleUser] = useState<GoogleUser | null>(() => {
    const saved = localStorage.getItem('prime_restaurant_google_user');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { return null; }
    }
    return null;
  });
  const [isGoogleAuthModalOpen, setIsGoogleAuthModalOpen] = useState<boolean>(false);
  const [isLocationModalOpen, setIsLocationModalOpen] = useState<boolean>(false);
  const [isWelcomeSplashOpen, setIsWelcomeSplashOpen] = useState<boolean>(true);

  const [customerName, setCustomerName] = useState<string>(() => googleUser?.name || '');
  const [customerPhoneOrEmail, setCustomerPhoneOrEmail] = useState<string>(() => googleUser?.email || '');
  const [confirmationCode, setConfirmationCode] = useState<string>('');
  const [currentLoyaltyMember, setCurrentLoyaltyMember] = useState<LoyaltyMember | null>(null);
  const [isLoyaltyModalOpen, setIsLoyaltyModalOpen] = useState<boolean>(false);

  const handleSignInGoogle = (user: GoogleUser) => {
    setGoogleUser(user);
    setCustomerName(user.name);
    setCustomerPhoneOrEmail(user.email);
    localStorage.setItem('prime_restaurant_google_user', JSON.stringify(user));
  };

  const handleSignOutGoogle = () => {
    setGoogleUser(null);
    localStorage.removeItem('prime_restaurant_google_user');
  };

  // Active Customer Order Tracker
  const [activeCustomerOrder, setActiveCustomerOrder] = useState<Order | null>(null);

  // App Base URL for QR generation
  const appUrl = window.location.origin;

  // Real-time updates: two scoped SSE streams below (customer table-scoped,
  // and staff full-detail), instead of one broadcast-everything stream.
  // Customer real-time stream: scoped to this table only (order status +
  // menu/table availability). Reopens whenever the table number changes.
  useEffect(() => {
    if (!tableNumber) return;
    const eventSource = new EventSource(`/api/events/table/${tableNumber}`);
    eventSource.onopen = () => setIsRealtimeConnected(true);
    eventSource.onerror = () => setIsRealtimeConnected(false);
    eventSource.onmessage = (event) => {
      try {
        const payload = JSON.parse(event.data);
        if (payload.type === 'ORDER_CREATED' || payload.type === 'ORDER_UPDATED') {
          if (payload.data.order) {
            setOrders(prev => {
              const exists = prev.some(o => o.id === payload.data.order.id);
              return exists
                ? prev.map(o => (o.id === payload.data.order.id ? payload.data.order : o))
                : [payload.data.order, ...prev];
            });
          }
        } else if (payload.type === 'MENU_UPDATED') {
          if (Array.isArray(payload.data)) setMenuItems(payload.data);
        }
      } catch (e) {
        console.error('Error parsing SSE event', e);
      }
    };
    return () => eventSource.close();
  }, [tableNumber]);

  // Staff real-time stream: full order/menu/table detail. Only opens once
  // logged into the admin or kitchen view (session-gated on the server too).
  useEffect(() => {
    if (!isAdminAuthenticated && !isKitchenAuthenticated) return;
    const eventSource = new EventSource('/api/events');
    eventSource.onopen = () => setIsRealtimeConnected(true);
    eventSource.onerror = () => setIsRealtimeConnected(false);
    eventSource.onmessage = (event) => {
      try {
        const payload = JSON.parse(event.data);
        if (payload.type === 'ORDER_CREATED') {
          if (payload.data.order) {
            setOrders(prev => [payload.data.order, ...prev.filter(o => o.id !== payload.data.order.id)]);
          }
        } else if (payload.type === 'ORDER_UPDATED') {
          if (payload.data.order) {
            setOrders(prev => prev.map(o => (o.id === payload.data.order.id ? payload.data.order : o)));
          }
        } else if (payload.type === 'MENU_UPDATED') {
          if (Array.isArray(payload.data)) setMenuItems(payload.data);
        } else if (payload.type === 'TABLES_UPDATED') {
          if (Array.isArray(payload.data)) setTables(payload.data);
        } else if (payload.type === 'ORDER_DELETED') {
          if (payload.data?.id) setOrders(prev => prev.filter(o => o.id !== payload.data.id));
        } else if (payload.type === 'ORDERS_CLEANED_UP') {
          fetchStaffState(); // simplest correct way to reflect a bulk deletion
        }
      } catch (e) {
        console.error('Error parsing SSE event', e);
      }
    };
    return () => eventSource.close();
  }, [isAdminAuthenticated, isKitchenAuthenticated]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const urlView = params.get('view');
    const urlTable = params.get('table');

    if (urlView === 'kitchen') {
      setAuthModalTarget('kitchen');
      setIsAdminAuthModalOpen(true);
      setCurrentView('customer');
    } else if (urlView === 'admin') {
      setAuthModalTarget('admin');
      setIsAdminAuthModalOpen(true);
      setCurrentView('customer');
    }

    if (urlTable) {
      const parsedNum = parseInt(urlTable, 10);
      if (!isNaN(parsedNum) && parsedNum > 0) {
        setTableNumber(parsedNum);
        setIsTableModalOpen(false);
        if (!urlView) setCurrentView('customer');
      } else {
        setIsTableModalOpen(true);
      }
    } else {
      setTableNumber(1); // Default to Table 1
    }

    // Fetch initial state from server API
    fetchState();
  }, []);

  // Publicly-readable data: menu + tables always, plus only the orders for
  // the current table (customers should never receive every other table's
  // orders or the full loyalty member list — that was a data-exposure bug
  // in the original build).
  const fetchState = async () => {
    try {
      const [menuRes, tablesRes] = await Promise.all([
        fetch('/api/menu').then(r => (r.ok ? r.json() : null)),
        fetch('/api/tables').then(r => (r.ok ? r.json() : null))
      ]);
      if (menuRes) setMenuItems(menuRes);
      if (tablesRes) setTables(tablesRes);

      if (tableNumber) {
        const myOrders = await fetch(`/api/orders/table/${tableNumber}`).then(r => (r.ok ? r.json() : null));
        if (myOrders) setOrders(myOrders);
      }
    } catch {
      showError('Could not load the latest menu/table data. Pull to refresh or check your connection.');
    }
  };

  // Full order list + loyalty list are admin/kitchen-only. Fetch them once
  // logged into either view, and refresh whenever that view is active.
  const fetchStaffState = async () => {
    try {
      const [ordersRes, loyaltyRes] = await Promise.all([
        fetch('/api/orders').then(r => (r.ok ? r.json() : null)),
        fetch('/api/loyalty').then(r => (r.ok ? r.json() : null))
      ]);
      if (ordersRes) setOrders(ordersRes);
      if (loyaltyRes) setLoyaltyMembers(loyaltyRes);
    } catch {
      showError('Could not refresh orders/loyalty data.');
    }
  };

  useEffect(() => {
    if (currentView === 'admin' || currentView === 'kitchen') {
      fetchStaffState();
    }
  }, [currentView]);

  // View Switcher with Security Lock for Kitchen & Admin
  const handleViewChange = (newView: AppViewMode) => {
    if (newView === 'kitchen' && !isKitchenAuthenticated) {
      setAuthModalTarget('kitchen');
      setIsAdminAuthModalOpen(true);
      return;
    }
    if (newView === 'admin' && !isAdminAuthenticated) {
      setAuthModalTarget('admin');
      setIsAdminAuthModalOpen(true);
      return;
    }
    setCurrentView(newView);
  };

  const handleAuthenticateAdmin = async (pass: string): Promise<boolean> => {
    const endpoint = authModalTarget === 'kitchen' ? '/api/auth/kitchen/login' : '/api/auth/admin/login';
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password: pass })
      });
      if (!res.ok) return false;

      if (authModalTarget === 'kitchen') {
        setIsKitchenAuthenticated(true);
        setIsAdminAuthModalOpen(false);
        setCurrentView('kitchen');
      } else {
        setIsAdminAuthenticated(true);
        setIsAdminAuthModalOpen(false);
        setCurrentView('admin');
      }
      return true;
    } catch {
      showError('Could not reach the server. Check your connection and try again.');
      return false;
    }
  };

  const handleLockAdmin = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
    } catch {
      // Even if the network call fails, still clear local UI state below.
    }
    setIsAdminAuthenticated(false);
    setIsKitchenAuthenticated(false);
    setCurrentView('customer');
  };

  // Keep active order updated for current table
  useEffect(() => {
    if (tableNumber) {
      const tableOrder = orders.find(o => o.tableNumber === tableNumber && o.status !== 'paid' && o.status !== 'cancelled');
      setActiveCustomerOrder(tableOrder || null);
    }
  }, [tableNumber, orders]);

  // Cart operations
  const handleDirectAddToCart = (dish: MenuItem) => {
    setCartItems(prev => {
      const existingIndex = prev.findIndex(
        i => i.menuItem.id === dish.id && i.selectedCustomizations.length === 0 && !i.specialInstructions
      );
      if (existingIndex > -1) {
        const updated = [...prev];
        const existing = updated[existingIndex];
        const newQty = existing.quantity + 1;
        updated[existingIndex] = {
          ...existing,
          quantity: newQty,
          itemTotal: dish.price * newQty
        };
        return updated;
      }
      const cartItemId = 'cart-' + Date.now() + '-' + Math.random().toString(36).substring(2, 5);
      return [
        ...prev,
        {
          cartItemId,
          menuItem: dish,
          quantity: 1,
          selectedCustomizations: [],
          specialInstructions: '',
          itemTotal: dish.price
        }
      ];
    });
  };

  const handleAddToCart = (itemData: Omit<CartItem, 'cartItemId'>) => {
    const cartItemId = 'cart-' + Date.now() + '-' + Math.random().toString(36).substring(2, 5);
    setCartItems(prev => [...prev, { ...itemData, cartItemId }]);
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (cartItemId: string, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveCartItem(cartItemId);
    } else {
      setCartItems(prev => prev.map(item => {
        if (item.cartItemId === cartItemId) {
          const unitPrice = item.itemTotal / item.quantity;
          return {
            ...item,
            quantity: newQty,
            itemTotal: unitPrice * newQty
          };
        }
        return item;
      }));
    }
  };

  const handleRemoveCartItem = (cartItemId: string) => {
    setCartItems(prev => prev.filter(i => i.cartItemId !== cartItemId));
  };

  // Submit Order to Kitchen
  const handleSubmitOrder = async (orderConfig: {
    paymentMethod: 'pay_at_counter' | 'card' | 'cash';
    loyaltyPointsRedeemed: number;
    orderNote: string;
  }) => {
    const subtotal = cartItems.reduce((acc, item) => acc + item.itemTotal, 0);
    const tax = subtotal * 0.08;
    const serviceCharge = subtotal * 0.05;
    const discount = orderConfig.loyaltyPointsRedeemed * 100;
    const totalAmount = Math.max(0, subtotal + tax + serviceCharge - discount);

    const payload = {
      tableNumber: tableNumber || 1,
      customerName: customerName || `Table ${tableNumber || 1} Guest`,
      customerPhoneOrEmail: customerPhoneOrEmail || '',
      items: cartItems,
      subtotal,
      tax,
      serviceCharge,
      discount,
      totalAmount,
      loyaltyPointsRedeemed: orderConfig.loyaltyPointsRedeemed,
      paymentMethod: orderConfig.paymentMethod,
      orderNote: orderConfig.orderNote
    };

    // A stable idempotency key per submit attempt so a flaky mobile network
    // retry can never create two real orders for one tap of "confirm".
    const idempotencyKey = `order-${tableNumber}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Idempotency-Key': idempotencyKey },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        const createdOrder: Order = await res.json();
        setOrders(prev => [createdOrder, ...prev]);
        setActiveCustomerOrder(createdOrder);
        setCartItems([]);
      } else {
        const body = await res.json().catch(() => ({ error: 'Could not place your order.' }));
        showError(body.error || 'Could not place your order. Please try again.');
      }
    } catch {
      showError('Could not reach the kitchen. Check your connection and try again — your order was NOT placed.');
    }
  };

  // Kitchen / Admin Update Order Status
  const handleUpdateOrderStatus = async (orderId: string, status: OrderStatus, paymentStatus?: 'paid' | 'unpaid') => {
    try {
      const res = await fetch(`/api/orders/${orderId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, paymentStatus })
      });

      if (res.ok) {
        const updated: Order = await res.json();
        setOrders(prev => prev.map(o => o.id === orderId ? updated : o));
      } else {
        showError('Could not update order status. Please try again.');
      }
    } catch {
      showError('Could not reach the server to update order status.');
    }
  };

  const handleDeleteOrder = async (orderId: string) => {
    try {
      const res = await fetch(`/api/orders/${orderId}`, { method: 'DELETE' });
      if (res.ok) {
        setOrders(prev => prev.filter(o => o.id !== orderId));
      } else {
        showError('Could not delete this order. Please try again.');
      }
    } catch {
      showError('Could not reach the server to delete this order.');
    }
  };

  const handleCleanupOldOrders = async (olderThanDays: number): Promise<number | null> => {
    try {
      const res = await fetch('/api/admin/orders/cleanup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ olderThanDays })
      });
      if (res.ok) {
        const result = await res.json();
        await fetchStaffState(); // refresh the order list to reflect the deletion
        return result.ordersDeleted;
      }
      showError('Could not clean up old orders. Please try again.');
      return null;
    } catch {
      showError('Could not reach the server to clean up old orders.');
      return null;
    }
  };

  // Admin Update Menu Item / Stock
  const handleUpdateMenuItem = async (updatedItem: MenuItem) => {
    try {
      const res = await fetch(`/api/menu/${updatedItem.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedItem)
      });

      if (res.ok) {
        const item: MenuItem = await res.json();
        setMenuItems(prev => prev.map(m => m.id === item.id ? item : m));
      } else {
        const body = await res.json().catch(() => ({ error: 'Could not save menu item changes.' }));
        showError(describeApiError(body) || 'Could not save menu item changes. Please try again.');
      }
    } catch {
      showError('Could not reach the server to save menu item changes.');
    }
  };

  // Admin Add New Dish
  const handleAddMenuItem = async (newItem: Partial<MenuItem>) => {
    try {
      const res = await fetch('/api/menu', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newItem)
      });

      if (res.ok) {
        const added: MenuItem = await res.json();
        setMenuItems(prev => [...prev, added]);
      } else {
        const body = await res.json().catch(() => ({ error: 'Could not add dish.' }));
        showError(describeApiError(body) || 'Could not add dish. Please check the fields and try again.');
      }
    } catch {
      showError('Could not reach the server to add the dish.');
    }
  };

  // Admin Delete Menu Item
  const handleDeleteMenuItem = async (id: string) => {
    try {
      const res = await fetch(`/api/menu/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setMenuItems(prev => prev.filter(m => m.id !== id));
      } else {
        showError('Could not delete this dish. Please try again.');
      }
    } catch {
      showError('Could not reach the server to delete this dish.');
    }
  };

  // Admin Add Table
  const handleAddTable = async (tableNumber: number, capacity: number) => {
    try {
      const res = await fetch('/api/tables', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tableNumber, capacity })
      });
      if (res.ok) {
        const table: Table = await res.json();
        setTables(prev => {
          const exists = prev.some(t => t.tableNumber === table.tableNumber);
          if (exists) return prev.map(t => t.tableNumber === table.tableNumber ? table : t);
          return [...prev, table].sort((a, b) => a.tableNumber - b.tableNumber);
        });
      } else {
        showError('Could not save the table. Please try again.');
      }
    } catch {
      showError('Could not reach the server to save the table.');
    }
  };

  // Admin Delete Table
  const handleDeleteTable = async (tableNumber: number) => {
    try {
      const res = await fetch(`/api/tables/${tableNumber}`, { method: 'DELETE' });
      if (res.ok) {
        setTables(prev => prev.filter(t => t.tableNumber !== tableNumber));
      } else {
        showError('Could not delete this table. Please try again.');
      }
    } catch {
      showError('Could not reach the server to delete this table.');
    }
  };

  // Verify Loyalty Member Code (customer self-service: exact match on their
  // own phone/email only, via the public lookup endpoint)
  const handleVerifyLoyalty = async (query: string, code: string) => {
    try {
      const res = await fetch(`/api/loyalty/lookup?identifier=${encodeURIComponent(query)}`);
      if (res.ok) {
        const member: LoyaltyMember | null = await res.json();
        if (member) {
          setCurrentLoyaltyMember(member);
          setCustomerName(member.name);
          return;
        }
      }
      // No existing member found -> register a new one.
      const regRes = await fetch('/api/loyalty', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: customerName, phoneOrEmail: query, confirmationCode: code })
      });
      if (regRes.ok) {
        const newMem = await regRes.json();
        setCurrentLoyaltyMember(newMem);
      } else {
        showError('Could not verify or register loyalty membership. Please try again.');
      }
    } catch {
      showError('Could not reach the server to verify loyalty membership.');
    }
  };

  const cartSubtotal = cartItems.reduce((acc, item) => acc + item.itemTotal, 0);

  return (
    <div className="min-h-screen bg-zinc-100 text-zinc-900 font-sans selection:bg-orange-500 selection:text-white">

      {/* Global error toast: replaces the old "silently pretend it worked" behavior */}
      {errorToast && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[9999] bg-red-600 text-white px-4 py-3 rounded-xl shadow-lg text-sm font-medium max-w-md text-center">
          {errorToast}
        </div>
      )}

      {/* Persistent App Navigation Header */}
      <HeaderNav
        currentView={currentView}
        onViewChange={handleViewChange}
        tableNumber={tableNumber}
        onChangeTableClick={() => setIsTableModalOpen(true)}
        onOpenQRScanner={() => setIsQRScannerModalOpen(true)}
        onOpenLocation={() => setIsLocationModalOpen(true)}
        onOpenGoogleAuth={() => setIsGoogleAuthModalOpen(true)}
        googleUser={googleUser}
        isRealtimeConnected={isRealtimeConnected}
        cartCount={cartItems.reduce((acc, i) => acc + i.quantity, 0)}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenLoyalty={() => setIsLoyaltyModalOpen(true)}
        loyaltyPoints={currentLoyaltyMember?.pointsBalance}
        customerName={customerName}
        lang={lang}
        onLanguageChange={setLang}
        isAdminAuthenticated={isAdminAuthenticated}
        isKitchenAuthenticated={isKitchenAuthenticated}
      />

      {/* Main View Router */}
      <main>
        {currentView === 'customer' && (
          <>
            <CustomerView
              menuItems={menuItems}
              tableNumber={tableNumber || 1}
              onSelectItem={(item) => setSelectedDishForCustomization(item)}
              onDirectAddToCart={handleDirectAddToCart}
              cartCount={cartItems.reduce((acc, i) => acc + i.quantity, 0)}
              cartSubtotal={cartSubtotal}
              onOpenCart={() => setIsCartOpen(true)}
              onOpenQRScanner={() => setIsQRScannerModalOpen(true)}
              onOpenLocation={() => setIsLocationModalOpen(true)}
              onOpenGoogleAuth={() => setIsGoogleAuthModalOpen(true)}
              lang={lang}
              activeOrder={activeCustomerOrder}
            />

            {/* Active Order Progress Bar (Customer View) */}
            <OrderStatusTracker activeOrder={activeCustomerOrder} hasCartItems={cartItems.length > 0} lang={lang} />
          </>
        )}

        {currentView === 'kitchen' && isKitchenAuthenticated && (
          <KitchenDisplay
            orders={orders}
            onUpdateStatus={handleUpdateOrderStatus}
            lang={lang}
          />
        )}

        {currentView === 'admin' && isAdminAuthenticated && (
          <AdminDashboard
            menuItems={menuItems}
            orders={orders}
            tables={tables}
            loyaltyMembers={loyaltyMembers}
            onUpdateAdminPassword={handleUpdateAdminPassword}
            onUpdateKitchenPin={handleUpdateKitchenPin}
            onUpdateMenuItem={handleUpdateMenuItem}
            onAddMenuItem={handleAddMenuItem}
            onDeleteMenuItem={handleDeleteMenuItem}
            onAddTable={handleAddTable}
            onDeleteTable={handleDeleteTable}
            onUpdateOrderStatus={handleUpdateOrderStatus}
            onDeleteOrder={handleDeleteOrder}
            onCleanupOldOrders={handleCleanupOldOrders}
            onLockAdmin={handleLockAdmin}
            appUrl={appUrl}
            lang={lang}
          />
        )}
      </main>

      {/* MODALS & DRAWERS */}
      
      {/* Admin / Kitchen Authentication Lock Modal */}
      <AdminAuthModal
        isOpen={isAdminAuthModalOpen}
        onClose={() => setIsAdminAuthModalOpen(false)}
        onAuthenticate={handleAuthenticateAdmin}
        lang={lang}
        targetView={authModalTarget}
      />

      {/* Table QR Camera Scanner Modal */}
      <QRScannerModal
        isOpen={isQRScannerModalOpen}
        onClose={() => setIsQRScannerModalOpen(false)}
        onSelectTable={(num) => setTableNumber(num)}
        lang={lang}
      />

      {/* 1. Table Selection / Confirmation Modal */}
      <TableConfirmModal
        isOpen={isTableModalOpen}
        currentTable={tableNumber}
        tables={tables}
        onConfirm={(num) => {
          setTableNumber(num);
          setIsTableModalOpen(false);
        }}
        lang={lang}
      />

      {/* 2. Dish Customizer Modal */}
      <ItemCustomizerModal
        item={selectedDishForCustomization}
        isOpen={!!selectedDishForCustomization}
        onClose={() => setSelectedDishForCustomization(null)}
        onAddToCart={handleAddToCart}
        lang={lang}
      />

      {/* 3. Shopping Cart & Bill Breakdown Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveCartItem}
        tableNumber={tableNumber || 1}
        customerName={customerName}
        setCustomerName={setCustomerName}
        customerPhoneOrEmail={customerPhoneOrEmail}
        setCustomerPhoneOrEmail={setCustomerPhoneOrEmail}
        confirmationCode={confirmationCode}
        setConfirmationCode={setConfirmationCode}
        loyaltyMember={currentLoyaltyMember}
        onVerifyLoyalty={handleVerifyLoyalty}
        googleUser={googleUser}
        onOpenGoogleAuth={() => setIsGoogleAuthModalOpen(true)}
        onSubmitOrder={handleSubmitOrder}
        lang={lang}
      />

      {/* 4. Loyalty Profile & Order History Modal */}
      <OrderHistoryModal
        isOpen={isLoyaltyModalOpen}
        onClose={() => setIsLoyaltyModalOpen(false)}
        member={currentLoyaltyMember}
        orders={orders.filter(o => o.tableNumber === tableNumber || o.customerPhoneOrEmail === customerPhoneOrEmail)}
        lang={lang}
      />

      {/* 5. Google OAuth Authentication Modal */}
      <GoogleAuthModal
        isOpen={isGoogleAuthModalOpen}
        onClose={() => setIsGoogleAuthModalOpen(false)}
        currentUser={googleUser}
        onSignInSuccess={handleSignInGoogle}
        onSignOut={handleSignOutGoogle}
        lang={lang}
      />

      {/* 6. Prime Restaurant Location & Contact Modal */}
      <RestaurantLocationModal
        isOpen={isLocationModalOpen}
        onClose={() => setIsLocationModalOpen(false)}
        lang={lang}
      />

      {/* 7. Welcome Intro Animation Splash */}
      <WelcomeSplash
        isOpen={isWelcomeSplashOpen}
        onClose={() => setIsWelcomeSplashOpen(false)}
        lang={lang}
        onSelectLang={(newLang) => setLang(newLang)}
      />

    </div>
  );
}
