import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { spawn, ChildProcess } from 'child_process';
import fs from 'fs';
import path from 'path';
import os from 'os';

// Separate server instance with Telegram actually "configured" (fake token,
// since we're not hitting the real Telegram API) so we can verify the
// webhook secret is actually enforced, not just documented.

const PORT = 4124;
const BASE_URL = `http://localhost:${PORT}`;
let serverProcess: ChildProcess;
let tempDataDir: string;

function waitForHealth(retries = 40): Promise<void> {
  return new Promise((resolve, reject) => {
    const attempt = (n: number) => {
      fetch(`${BASE_URL}/api/health`)
        .then(res => (res.ok ? resolve() : retry(n)))
        .catch(() => retry(n));
    };
    const retry = (n: number) => {
      if (n <= 0) return reject(new Error('Server did not become healthy in time'));
      setTimeout(() => attempt(n - 1), 250);
    };
    attempt(retries);
  });
}

beforeAll(async () => {
  tempDataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'restaurant-test-telegram-'));
  serverProcess = spawn('npx', ['tsx', 'server.ts'], {
    cwd: process.cwd(),
    env: {
      ...process.env,
      NODE_ENV: 'test',
      PORT: String(PORT),
      DATABASE_DIR: tempDataDir,
      JWT_SECRET: 'test-secret-at-least-16-chars',
      ADMIN_INITIAL_PASSWORD: 'test-admin-pass',
      KITCHEN_INITIAL_PIN: '9999',
      ALLOWED_ORIGINS: '',
      // Fake but present — enough to make telegramConfigured = true without
      // ever calling the real Telegram API in this test.
      TELEGRAM_BOT_TOKEN: 'fake-token-for-tests',
      TELEGRAM_BOT_USERNAME: 'FakeTestBot',
      TELEGRAM_WEBHOOK_SECRET: 'test-webhook-secret-value'
    },
    stdio: 'pipe'
  });
  await waitForHealth();
}, 30_000);

afterAll(() => {
  serverProcess?.kill();
  if (tempDataDir) fs.rmSync(tempDataDir, { recursive: true, force: true });
});

describe('telegram webhook security (with secret configured)', () => {
  it('reports configured: true', async () => {
    const res = await fetch(`${BASE_URL}/api/auth/telegram/config`);
    const body = await res.json();
    expect(body.configured).toBe(true);
  });

  it('issues a real token when starting verification', async () => {
    const res = await fetch(`${BASE_URL}/api/auth/telegram/start`, { method: 'POST' });
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.token).toBeTruthy();
    expect(body.deepLink).toContain('FakeTestBot');
  });

  it('rejects a webhook call with the wrong secret token', async () => {
    const res = await fetch(`${BASE_URL}/api/telegram/webhook`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Telegram-Bot-Api-Secret-Token': 'wrong-secret' },
      body: JSON.stringify({ message: { text: '/start faketoken', from: { id: 1, username: 'attacker' } } })
    });
    expect(res.status).toBe(401);
  });

  it('rejects a webhook call with no secret token header at all', async () => {
    const res = await fetch(`${BASE_URL}/api/telegram/webhook`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: { text: '/start faketoken', from: { id: 1, username: 'attacker' } } })
    });
    expect(res.status).toBe(401);
  });

  it('accepts a webhook call with the correct secret and marks the token verified', async () => {
    const startRes = await fetch(`${BASE_URL}/api/auth/telegram/start`, { method: 'POST' });
    const { token } = await startRes.json();

    const webhookRes = await fetch(`${BASE_URL}/api/telegram/webhook`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Telegram-Bot-Api-Secret-Token': 'test-webhook-secret-value'
      },
      body: JSON.stringify({
        message: { text: `/start ${token}`, from: { id: 555, username: 'real_customer', first_name: 'Test' } }
      })
    });
    expect(webhookRes.status).toBe(200);

    const statusRes = await fetch(`${BASE_URL}/api/auth/telegram/status/${token}`);
    const status = await statusRes.json();
    expect(status.status).toBe('verified');
    expect(status.telegramUsername).toBe('real_customer');
  });
});
